package tp_java;

public class Voiture {
	
	protected String marque;
	protected int annee;
	protected double numerochassi;

	 public Voiture(String marqueVoiture){
		marque = marqueVoiture;
	}
	
	 public Voiture(int annee) {
		 this.annee = annee;
	 }
	 
	 public Voiture() {
		 
	 }
	
}
