package tp_java;

public class Triangle {
	
	public int cote1;
	public int cote2;
	public int cote3;
	public int base;
	public int hauteur;
	public int xBase;
	public int yBase;
	public int xApres;
	public int yApres;
	public int reduce;

	public void perimetre(int cote1, int cote2, int cote3) {
		int result1 = cote1+cote2+cote3;
		System.out.println("le périmètre : " +result1);
	}
	
	public void air(int base, int hauteur) {
		int result2 = (base * hauteur) / 2;
		System.out.println("l'air : " +result2);
	}
	
	public void deplacement(int xBase, int yBase, int yApres, int xApres) {
		System.out.println("avant déplacement: x : "+xBase+" y : "+yBase);
		System.out.println("apres déplacement: x : "+xApres+" y : "+yApres);
	}
	
	public void reduire (int cote1, int reduce) {
		System.out.println("cote1 passe de : "+cote1+ " à :" +reduce);
	}

}
