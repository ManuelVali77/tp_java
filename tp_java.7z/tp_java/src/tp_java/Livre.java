package tp_java;

public class Livre {

	private String nom;
	private String auteur;
	private String categorie;
	private String isbn;
	
	public Livre(String nom, String auteur, String categorie, String isbn) {
		super();
		this.nom = nom;
		this.auteur = auteur;
		this.categorie = categorie;
		this.isbn = isbn;
	}

	public String getNom() {
		return nom;
	}

	public void setNom(String nom) {
		this.nom = nom;
	}

	public String getAuteur() {
		return auteur;
	}

	public void setAuteur(String auteur) {
		this.auteur = auteur;
	}

	public String getCategorie() {
		return categorie;
	}

	public void setCategorie(String categorie) {
		this.categorie = categorie;
	}

	public String getIsbn() {
		return isbn;
	}

	public void setIsbn(String isbn) {
		this.isbn = isbn;
	}
	
	@Override
	public String toString() {
		return "Livre [nom=" + nom + ", auteur=" + auteur + ", categorie=" + categorie + ", isbn=" + isbn + "]";
	}

	public void codeLivre(String nom, String prenom, String categorie, String isbn) {
		String nomLettre = nom.substring(0,2);
		String prenomLettre = prenom.substring(0,2);
		String categorieLettre = prenom.substring(0,1);
		String finisbn = nom.substring(nom.length()-2);
		
		System.out.println("code livre: "+nomLettre+prenomLettre+categorieLettre+finisbn);
	}

}
