package tp_java;

public class Etudiant {
	
	public int note1;
	public int note2;
	public int note3;
	public String nom;
	public String prenom;
	
	public void moyenne(int note1, int note2, int note3) {
		int array[] = {note1, note2, note3};
		float moyenne = 0;
		for (int nombre:array) {
			 System.out.print(nombre+" ");
			 int somme = 0;
			 for(int i = 0; i < array.length; i++){
			 somme += array[i];
			 }
			 
			 moyenne = (float) somme / array.length;
			 }
		System.out.print("\nMoyenne = "+moyenne+"\n");
		}

	public void initial(String nom, String prenom) {
		String premiereLettreNom = nom.substring(0,1);
		String premiereLettrePrenom = prenom.substring(0,1);
		System.out.println("Initial : "+premiereLettreNom + premiereLettrePrenom);
	}
	
	public void trigramme(String nom, String prenom) {
		String premiereLettreNom = nom.substring(0,1);
		String premiereLettrePrenom = prenom.substring(0,1);
		String finNom = nom.substring(nom.length()-1);
		System.out.println("le Trigramme :"+premiereLettrePrenom+premiereLettreNom+finNom);
	}

}
