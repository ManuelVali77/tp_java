package tp_java;

import java.util.ArrayList;
import java.util.List;


public class Bibliotheque {
	
	private ArrayList<Livre> listeLivre = new ArrayList<>();
	
	
	
	public ArrayList<Livre> getListeLivre() {
		return listeLivre;
	}



	@Override
	public String toString() {
		return "Bibliotheque [listeLivre=" + listeLivre + "]";
	}



	public void setListeLivre(ArrayList<Livre> listeLivre) {
		this.listeLivre = listeLivre;
	}



	
}
