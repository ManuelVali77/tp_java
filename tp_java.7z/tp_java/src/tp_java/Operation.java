package tp_java;

public class Operation {

	public int a;
	public int b;
	
	public void addition(int a, int b) {
		int result = a + b;
		System.out.println(result);
	}
	
	public void soustraction(int a, int b) {
		int result2 = a - b;
		System.out.println(result2);
	}
	
	public void multiplication(int a, int b) {
		int result3 = a * b;
		System.out.println(result3);
	}
	public void division(int a, int b) {
		int result4 = a / b;
		System.out.println(result4);
	}
}
