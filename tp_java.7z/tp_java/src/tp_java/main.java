package tp_java;

import java.util.HashMap;
import java.util.ArrayList;
import java.util.List;

import java.util.Scanner;

public class main {

	public static void main(String[] args) {

		Scanner scanner = new Scanner(System.in);
		System.out.println("Entre une chaine :");
		char[] array = new char[] { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q',
				'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z', 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L',
				'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z' };
		String userString = scanner.nextLine();
		HashMap<Character, Integer> charint = new HashMap<>();
		for (Character c : userString.toCharArray()) {
			if (charint.containsKey(c))
				charint.replace(c, charint.get(c).intValue() + 1);
			else
				charint.put(c, 1);
		}
		for (int i = 0; i < array.length; i++) {
			System.out.println(array[i] + " : " + (charint.get(array[i]) == null ? "0" : charint.get(array[i])));
		}

		System.out.println("Entre une chaine : ");
		String str = scanner.nextLine();
		System.out.println(str.toUpperCase());
		System.out.println(str.toLowerCase());

		System.out.println("Entre une chaine(2) : ");
		String str2 = scanner.nextLine();
		StringBuilder myString = new StringBuilder(str2);
		for (int i = 0; i < str2.length(); i += 2) {
			myString.setCharAt(i, '*');
		}
		System.out.println(myString);
	
		Bibliotheque biblio = new Bibliotheque();
		Livre livre1 = new Livre("La ligne verte", "Stephen King", "Thriller", "sdfssdfd");
		ArrayList<Livre> listeLivrebiblio = new ArrayList<>();
		listeLivrebiblio.add(livre1);
		biblio.setListeLivre(listeLivrebiblio);
		
		for (Livre livre : biblio.getListeLivre()) {
			System.out.println(livre.toString());
			
		}
		System.out.println(biblio.toString());	
		
		Triangle triangle = new Triangle();
		triangle.perimetre(3, 4, 6);
		triangle.air(3, 3);
		triangle.deplacement(3, 6, 2, 4);
		triangle.reduire(4, 2);
		
		Operation operation = new Operation();
		operation.addition(1 , 4);
		operation.division(66, 2);
		operation.multiplication(3, 20);
		operation.soustraction(89, 23);
				
		System.out.println("Entre ton nom : ");
		String nom = scanner.nextLine();
		
		System.out.println("Entre ton prenom : ");
		String prenom = scanner.nextLine();
		
		Etudiant etudiant = new Etudiant();
		etudiant.moyenne(12, 8, 15);
		etudiant.trigramme(nom, prenom);
		etudiant.initial(nom, prenom);
		
		Voiture voiture = new Voiture("Peugeot");
		Voiture voiture2 = new Voiture(1990);
		Voiture voiture3 = new Voiture();
		voiture3.numerochassi = 232.22;
		
		System.out.println(voiture.marque+" "+voiture2.annee + " "+voiture3.numerochassi);
		
		
	}
}
